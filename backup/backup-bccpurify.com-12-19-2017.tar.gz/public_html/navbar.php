<div class="button_container" id="toggle">
  <span class="top"></span>
  <span class="middle"></span>
  <span class="bottom"></span>
</div>

<div class="overlay" id="overlay">
  <nav class="overlay-menu">
    <ul>
      <li ><a href="index.php">Home</a></li>
      <li><a href="wwd.php">What We Do</a></li>
      <li><a href="leaders.php">Leaders</a></li>
      <li><a href="past.php">Past Semesters</a></li>
        <li><a href="documents.php">Documents</a></li>
        <li><a href="contact.php">Contact</a></li>
    </ul>
  </nav>
</div>