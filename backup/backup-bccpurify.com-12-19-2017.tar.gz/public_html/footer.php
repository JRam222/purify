<div class="col-lg-12 footer">        
    <p>810 W. Lookout Dr, Richardson, TX, 75080 | 806 281 7197</p>
    <p>&copy;2017 Purify Ministry</p>
    <p><a href="index.php">Home</a> | <a href="wwd.php">What We Do</a> | <a href="leaders.php">Leaders</a> | <a href="past.php">Past Semesters</a> | <a href="documents.php">Documents</a> | <a href="contact.php">Contact</a></p>
</div>